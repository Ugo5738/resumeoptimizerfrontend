declare module 'pdfjs-dist/build/pdf.worker.min.js' {
    const content: any;
    export default content;
}